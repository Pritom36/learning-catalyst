/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
      "./index.html",
      "./css/**/*.css",
      "./js/**/*.js"
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  